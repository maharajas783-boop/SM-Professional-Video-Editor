# SM Pro Video Editor — Professional Video Editing Suite

A full-stack professional video editor with Python/Flask backend and dark cinematic HTML/CSS frontend.

---

## Features

| Tool | Description |
|------|-------------|
| ✂ Trim & Cut | Clip video to precise start/end timestamps |
| ⬇ Compress | Reduce file size with H.264 encoding (High/Medium/Low quality) |
| ↔ Convert | Convert to MP4, AVI, MOV, MKV, WebM, FLV |
| ⊕ Merge | Concatenate multiple video clips into one |
| ♪ Extract Audio | Rip audio as MP3, WAV, or AAC |
| © Watermark | Overlay a logo/image with position & opacity control |
| T Text Overlay | Burn text onto video at any time range |
| ⬛ Thumbnail | Extract a single frame as JPG |

---

## Requirements

- Python 3.8+
- Flask
- FFmpeg (for all video processing)

---

## Installation & Setup

### 1. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 2. Install FFmpeg

**Ubuntu/Debian:**
```bash
sudo apt install ffmpeg
```

**macOS:**
```bash
brew install ffmpeg
```

**Windows:**
Download from https://ffmpeg.org/download.html and add to PATH.

### 3. Run the Application
```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## Project Structure

```
sm_pro_editor/
├── app.py                 # Flask backend — all API routes
├── requirements.txt
├── uploads/               # Uploaded media files
├── exports/               # Processed output files
├── templates/
│   └── index.html         # Main HTML UI
└── static/
    ├── css/
    │   └── style.css      # Dark cinematic stylesheet
    └── js/
        └── app.js         # Frontend logic
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/status` | Server status & FFmpeg check |
| POST | `/api/upload` | Upload media file |
| POST | `/api/trim` | Trim video |
| POST | `/api/compress` | Compress video |
| POST | `/api/convert` | Convert format/resolution |
| POST | `/api/merge` | Merge multiple videos |
| POST | `/api/extract-audio` | Extract audio track |
| POST | `/api/add-watermark` | Add image watermark |
| POST | `/api/add-text` | Burn text overlay |
| POST | `/api/thumbnail` | Extract frame as thumbnail |
| GET | `/api/files` | List uploaded files |
| POST | `/api/delete` | Delete a file |

---

## Made with ❤ by SM Pro Video Editor
