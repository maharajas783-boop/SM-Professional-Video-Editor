@echo off
setlocal enabledelayedexpansion
title SM Pro Video Editor
chcp 65001 >nul 2>&1

:: ═══ FAST STARTUP — no pause, no slow loops ═══
python --version >nul 2>&1
if errorlevel 1 (
    color 4F
    echo.
    echo  [!] Python not found. Install from https://python.org
    echo.
    pause & exit /b 1
)

:: Silent instant dependency check
pip show flask >nul 2>&1
if errorlevel 1 (
    echo  Installing dependencies...
    pip install flask werkzeug --quiet --disable-pip-version-check >nul 2>&1
)

:: Open browser after 1.5s then start server
start "" timeout /t 2 >nul & start "" "http://localhost:5000"

:: Launch server (no extra messages — app.py handles console output)
python app.py
