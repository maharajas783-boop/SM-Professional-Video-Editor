/*  SM PRO VIDEO EDITOR — app.js v5  */

// ── State ─────────────────────────────────────
const S = { media:[], exports:[], batch:[] };

// ── Splash ────────────────────────────────────
const STEPS = [
  [15,  'Checking Python environment…'],
  [30,  'Loading FFmpeg engine…'],
  [50,  'Initializing API endpoints…'],
  [65,  'Building media pipeline…'],
  [80,  'Preparing interface…'],
  [95,  'Loading tools…'],
  [100, 'Ready!'],
];
function runSplash() {
  const bar = document.getElementById('sp-fill');
  const msg = document.getElementById('sp-msg');
  const pct = document.getElementById('sp-pct');
  let i = 0;
  function tick() {
    if (i >= STEPS.length) {
      setTimeout(() => {
        const sp = document.getElementById('splash');
        sp.classList.add('hide');
        setTimeout(() => {
          sp.style.display = 'none';
          const app = document.getElementById('app');
          app.style.display = 'block';
          initApp();
        }, 600);
      }, 350);
      return;
    }
    const [p, s] = STEPS[i++];
    bar.style.width = p + '%';
    pct.textContent = p + '%';
    msg.textContent = s;
    setTimeout(tick, 300 + Math.random() * 250);
  }
  setTimeout(tick, 180);
}

// ── App init (runs after splash) ───────────────
function initApp() {
  initNav();
  initDrop();
  document.getElementById('fi').addEventListener('change', e => {
    uploadFiles([...e.target.files]);
    e.target.value = '';
  });
  initTimeline();
  initTheme();
  document.getElementById('btn-help').addEventListener('click', () => {
    document.getElementById('help-modal').style.display = 'flex';
  });
  initKeyboard();
  initQualityCards();
  drawWave();
  animatePH();
  // Tool nav click
  document.querySelectorAll('.tnb[data-tool]').forEach(b => {
    b.addEventListener('click', () => {
      document.querySelectorAll('.tnb').forEach(x => x.classList.remove('active'));
      document.querySelectorAll('.tp').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      const t = document.getElementById('tool-' + b.dataset.tool);
      if (t) t.classList.add('active');
    });
  });
  // Rotate buttons
  document.querySelectorAll('.rotb').forEach(b => {
    b.addEventListener('click', () => {
      document.querySelectorAll('.rotb').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
    });
  });
}

document.addEventListener('DOMContentLoaded', runSplash);

// ── Navigation ─────────────────────────────────
function initNav() {
  document.querySelectorAll('.nb[data-panel]').forEach(b => {
    b.addEventListener('click', () => switchPanel(b.dataset.panel));
  });
}
function switchPanel(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nb').forEach(b => b.classList.remove('active'));
  const panel = document.getElementById('panel-' + id);
  if (panel) panel.classList.add('active');
  const btn = document.querySelector(`.nb[data-panel="${id}"]`);
  if (btn) btn.classList.add('active');
}
function activateTool(name) {
  switchPanel('tools');
  setTimeout(() => {
    document.querySelectorAll('.tnb').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.tp').forEach(x => x.classList.remove('active'));
    const b = document.querySelector(`.tnb[data-tool="${name}"]`);
    if (b) b.classList.add('active');
    const t = document.getElementById('tool-' + name);
    if (t) t.classList.add('active');
  }, 60);
}

// ── Theme ──────────────────────────────────────
function initTheme() {
  document.getElementById('btn-theme').addEventListener('click', () => {
    document.body.classList.toggle('light');
  });
}

// ── Help ───────────────────────────────────────
function closeHelp() {
  document.getElementById('help-modal').style.display = 'none';
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeHelp();
});

// ── Keyboard shortcuts ──────────────────────────
function initKeyboard() {
  document.addEventListener('keydown', e => {
    if (['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)) return;
    const m = {'1':'dashboard','2':'media','3':'slideshow','4':'tools','5':'batch','6':'exports'};
    if (m[e.key]) switchPanel(m[e.key]);
  });
}

// ── Waveform ───────────────────────────────────
function drawWave() {
  const c = document.getElementById('wv');
  if (!c) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height, mid = H / 2;
  ctx.clearRect(0, 0, W, H);
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0,   '#6366F1');
  g.addColorStop(0.5, '#A78BFA');
  g.addColorStop(1,   '#06B6D4');
  ctx.strokeStyle = g; ctx.lineWidth = 1.4;
  ctx.beginPath();
  for (let x = 0; x <= W; x++) {
    const t = x / W;
    const a = (Math.sin(t*18)*0.5 + Math.sin(t*7+1)*0.3 + Math.sin(t*31+2)*0.2) * 28;
    ctx.lineTo(x, mid + a);
  }
  ctx.stroke();
  ctx.globalAlpha = 0.07;
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.moveTo(0, mid);
  for (let x = 0; x <= W; x++) {
    const t = x / W;
    const a = (Math.sin(t*18)*0.5 + Math.sin(t*7+1)*0.3 + Math.sin(t*31+2)*0.2) * 28;
    ctx.lineTo(x, mid + a);
  }
  ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 1;
}
function animatePH() {
  const ph = document.getElementById('fe-ph');
  if (!ph) return;
  let pos = 30, dir = 1;
  setInterval(() => {
    pos += dir * 0.35;
    if (pos > 88 || pos < 5) dir *= -1;
    ph.style.left = pos + '%';
  }, 50);
}

// ── Quality card radios ─────────────────────────
function initQualityCards() {
  document.querySelectorAll('.ql input').forEach(r => {
    r.addEventListener('change', () => {
      const grid = r.closest('.qgrid');
      grid.querySelectorAll('.qcard').forEach(c => c.classList.remove('sel'));
      r.nextElementSibling.classList.add('sel');
    });
  });
}

// ── Drag & Drop ────────────────────────────────
function initDrop() {
  const dz = document.getElementById('dropzone');
  if (!dz) return;
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('over'));
  dz.addEventListener('drop', e => {
    e.preventDefault(); dz.classList.remove('over');
    uploadFiles([...e.dataTransfer.files]);
  });
}

// ── Upload ─────────────────────────────────────
async function uploadFiles(files) {
  if (!files.length) return;
  const prog = document.getElementById('up-prog');
  const fill = document.getElementById('up-fill');
  const stat = document.getElementById('up-status');
  prog.style.display = 'block';

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    fill.style.width = Math.round(i / files.length * 100) + '%';
    stat.textContent = `Uploading ${i+1}/${files.length}: ${f.name}`;
    const fd = new FormData();
    fd.append('file', f);
    try {
      const r = await fetch('/api/upload', { method:'POST', body:fd });
      const d = await r.json();
      if (d.success) { S.media.push(d); toast(f.name + ' uploaded ✓', 'ok'); }
      else toast(f.name + ': ' + (d.error || 'Upload failed'), 'err');
    } catch {
      toast('Network error: ' + f.name, 'err');
    }
  }

  fill.style.width = '100%';
  stat.textContent = `Done — ${files.length} file(s) uploaded`;
  setTimeout(() => { prog.style.display = 'none'; fill.style.width = '0%'; }, 2000);
  renderMedia();
  refreshSelects();
}

// ── Media Library ──────────────────────────────
function renderMedia() {
  const grid  = document.getElementById('ml-grid');
  const empty = document.getElementById('ml-empty');
  if (!grid) return;
  if (!S.media.length) {
    empty.style.display = '';
    grid.innerHTML = '';
    return;
  }
  empty.style.display = 'none';
  const COLORS = { video:'#6366F1', audio:'#F59E0B', image:'#10B981' };
  const ICONS  = { video:'🎬', audio:'🎵', image:'🖼' };
  grid.innerHTML = S.media.map((f, i) => {
    const ic = ICONS[f.file_type] || '📄';
    const co = COLORS[f.file_type] || '#7878A0';
    const meta = [f.size_mb + ' MB', f.duration ? fmt(f.duration) : null, f.resolution || null].filter(Boolean).join(' · ');
    return `<div class="mlc">
      <div class="mlc-thumb">
        <span>${ic}</span>
        <span class="mlc-badge" style="background:${co}22;color:${co};border:1px solid ${co}44">${f.file_type.toUpperCase()}</span>
      </div>
      <div class="mlc-info">
        <div class="mlc-name" title="${f.filename}">${f.filename}</div>
        <div class="mlc-meta">${meta}</div>
      </div>
      <div class="mlc-acts">
        <button class="mlb use" onclick="useFile(${i})">Use</button>
        <button class="mlb del" onclick="delFile(${i})">Delete</button>
      </div>
    </div>`;
  }).join('');
}

function fmt(s) {
  const m = Math.floor(s/60), ss = Math.floor(s%60);
  return `${m}:${String(ss).padStart(2,'0')}`;
}

function useFile(i) {
  const f = S.media[i];
  switchPanel('tools');
  setTimeout(() => {
    document.querySelectorAll('.fsel').forEach(sel => {
      for (const o of sel.options) {
        if (o.value === f.file_id) { sel.value = f.file_id; break; }
      }
    });
    toast(f.filename + ' selected in all tools', 'info');
  }, 80);
}

async function delFile(i) {
  const f = S.media[i];
  try {
    await fetch('/api/delete', { method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ file_id: f.file_id, folder:'uploads' }) });
  } catch {}
  S.media.splice(i, 1);
  renderMedia();
  refreshSelects();
  toast(f.filename + ' deleted', 'info');
}

// ── Populate all <select> dropdowns ────────────
function refreshSelects() {
  const vids  = S.media.filter(f => f.file_type === 'video');
  const auds  = S.media.filter(f => f.file_type === 'audio');
  const imgs  = S.media.filter(f => f.file_type === 'image');
  const all   = S.media;

  function fill(id, items, ph) {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = `<option value="">${ph}</option>` +
      items.map(f => `<option value="${f.file_id}">${f.filename}</option>`).join('');
  }

  fill('trim-file',    vids, '— Select video —');
  fill('compress-file',vids, '— Select video —');
  fill('convert-file', all,  '— Select file —');
  fill('audio-file',   vids, '— Select video —');
  fill('wm-vid',       vids, '— Select video —');
  fill('wm-img',       imgs, '— Select image —');
  fill('text-file',    vids, '— Select video —');
  fill('speed-file',   vids, '— Select video —');
  fill('rotate-file',  vids, '— Select video —');
  fill('thumb-file',   vids, '— Select video —');
  fill('bch-file',     all,  '— Select file —');

  // Merge multi-select
  const ms = document.getElementById('merge-files');
  if (ms) ms.innerHTML = vids.map(f => `<option value="${f.file_id}">${f.filename}</option>`).join('');

  // Slideshow photo select
  const si = document.getElementById('ss-imgs');
  if (si) si.innerHTML = imgs.map(f => `<option value="${f.file_id}">${f.filename}</option>`).join('');

  // Slideshow audio select
  const sa = document.getElementById('ss-aud');
  if (sa) {
    sa.innerHTML = '<option value="">— Silent slideshow —</option>' +
      auds.map(f => `<option value="${f.file_id}">${f.filename}</option>`).join('');
  }
}

// ── Timeline slider ─────────────────────────────
function initTimeline() {
  const bar = document.getElementById('tl-bar');
  const lh  = document.getElementById('tl-l');
  const rh  = document.getElementById('tl-r');
  const rng = document.getElementById('tl-rng');
  const si  = document.getElementById('trim-s');
  const ei  = document.getElementById('trim-e');
  if (!bar) return;

  let lP = 0, rP = 100;

  function update() {
    lh.style.left  = lP + '%';
    rh.style.right = (100 - rP) + '%';
    rng.style.left  = lP + '%';
    rng.style.right = (100 - rP) + '%';
    const dur = parseFloat(ei ? ei.value : 10) || 10;
    if (si) si.value = Math.round(lP / 100 * dur * 10) / 10;
    if (ei) ei.value = Math.round(rP / 100 * dur * 10) / 10;
  }

  function drag(e, side) {
    e.preventDefault();
    const rect = bar.getBoundingClientRect();
    function mv(ev) {
      const cx = (ev.clientX || (ev.touches && ev.touches[0].clientX) || 0);
      const p  = Math.max(0, Math.min(100, (cx - rect.left) / rect.width * 100));
      if (side === 'l') lP = Math.min(p, rP - 5);
      else              rP = Math.max(p, lP + 5);
      update();
    }
    function up() {
      document.removeEventListener('mousemove', mv);
      document.removeEventListener('mouseup', up);
      document.removeEventListener('touchmove', mv);
      document.removeEventListener('touchend', up);
    }
    document.addEventListener('mousemove', mv);
    document.addEventListener('mouseup', up);
    document.addEventListener('touchmove', mv, { passive:false });
    document.addEventListener('touchend', up);
  }

  lh.addEventListener('mousedown',  e => drag(e, 'l'));
  rh.addEventListener('mousedown',  e => drag(e, 'r'));
  lh.addEventListener('touchstart', e => drag(e, 'l'), { passive:false });
  rh.addEventListener('touchstart', e => drag(e, 'r'), { passive:false });
  update();
}

// ── Merge chips ─────────────────────────────────
function updateMergeChips() {
  const ms   = document.getElementById('merge-files');
  const wrap = document.getElementById('merge-chips');
  if (!ms || !wrap) return;
  const sel = [...ms.selectedOptions];
  wrap.innerHTML = sel.length
    ? sel.map((o, i) => `<span class="mchip"><span>${i+1}</span>${o.text}</span>`).join('')
    : '<span class="ch-hint">Select videos above to see order</span>';
}

// ── Slideshow preview ───────────────────────────
function updateSSChips() {
  const ms   = document.getElementById('ss-imgs');
  const wrap = document.getElementById('ss-chips');
  const cnt  = document.getElementById('ss-cnt-lbl');
  if (!ms || !wrap) return;
  const sel = [...ms.selectedOptions];
  if (cnt) cnt.textContent = sel.length + ' photo' + (sel.length !== 1 ? 's' : '');
  wrap.innerHTML = sel.length
    ? sel.map((o, i) => `<span class="ss-chip"><span>${i+1}</span>${o.text}</span>`).join('')
    : '<span class="ch-hint">No photos selected yet</span>';
  updateSSPreview();
}

const SLIDE_COLORS = [
  'linear-gradient(135deg,#6366F1,#8B5CF6)',
  'linear-gradient(135deg,#EC4899,#F97316)',
  'linear-gradient(135deg,#10B981,#06B6D4)',
  'linear-gradient(135deg,#F59E0B,#EF4444)',
  'linear-gradient(135deg,#A78BFA,#6366F1)',
  'linear-gradient(135deg,#06B6D4,#10B981)',
];

function updateSSPreview() {
  const ms  = document.getElementById('ss-imgs');
  const pre = document.getElementById('ss-prev');
  const tl  = document.getElementById('ss-tl');
  const dur = parseInt(document.getElementById('ss-dur')?.value || 3);
  if (!ms || !pre) return;
  const sel = [...ms.selectedOptions];
  if (!sel.length) {
    pre.innerHTML = '<div class="ss-empty"><div style="font-size:2.8rem">🖼</div><p>Select photos to preview</p></div>';
    tl.innerHTML  = '<div class="ss-tl-empty">Timeline appears after selecting photos</div>';
    return;
  }
  // Grid preview
  pre.innerHTML = `<div class="ss-grid">${sel.map((o, i) =>
    `<div class="ss-thumb" style="background:${SLIDE_COLORS[i % SLIDE_COLORS.length]}">
       <div class="ss-thumb-n">${i+1}</div>
       <span style="font-size:1.4rem">🖼</span>
     </div>`
  ).join('')}</div>`;

  // Timeline bar
  tl.innerHTML = `<div class="ss-tl-bar">${sel.map((o, i) =>
    `<div class="ss-tl-seg" style="background:${SLIDE_COLORS[i % SLIDE_COLORS.length]}" title="${o.text}">${i+1}</div>`
  ).join('')}</div>
  <div style="font-size:.66rem;color:var(--mut);text-align:right;margin-top:4px">${sel.length} slides · ${sel.length * dur}s total</div>`;
}

// ── Speed control ───────────────────────────────
function setSpeed(v) {
  const r = document.getElementById('speed-rng');
  if (r) { r.value = v; document.getElementById('speed-val').textContent = v.toFixed(2) + '×'; }
  document.querySelectorAll('.spb').forEach(b => {
    b.classList.toggle('active', Math.abs(parseFloat(b.textContent) - v) < 0.01);
  });
}

// ── Processing overlay ──────────────────────────
function showOv(title, sub) {
  document.getElementById('po-title').textContent = title || 'Processing…';
  document.getElementById('po-sub').textContent   = sub   || 'FFmpeg is working — please wait';
  document.getElementById('proc-ov').style.display = 'flex';
}
function hideOv() {
  document.getElementById('proc-ov').style.display = 'none';
}

// ── Toast ───────────────────────────────────────
function toast(msg, type) {
  const w = document.getElementById('toasts');
  const t = document.createElement('div');
  t.className = 'toast ' + (type || 'info');
  t.textContent = msg;
  w.appendChild(t);
  setTimeout(() => {
    t.style.transition = 'opacity .3s,transform .3s';
    t.style.opacity = '0'; t.style.transform = 'translateX(16px)';
    setTimeout(() => t.remove(), 300);
  }, 3500);
}

// ── API call helper ─────────────────────────────
async function api(endpoint, payload) {
  const r = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return r.json();
}

// ── Show result ─────────────────────────────────
const OP_ICONS = { trim:'✂', compress:'⬇', convert:'↔', merge:'⊕', audio:'♪',
  watermark:'©', text:'T', thumbnail:'🖼', speed:'⏩', rotate:'↻', slideshow:'🎬', batch:'⚡' };

function showResult(boxId, data, opName) {
  const box = document.getElementById(boxId);
  if (!box) return;
  if (!data || !data.success) {
    box.className = 'rbox err';
    box.innerHTML = `<div class="rb-h">✗ ${opName} failed</div>
      <div class="rb-err">${data ? (data.details || data.error || 'Unknown error') : 'No response'}</div>`;
    return;
  }
  const metaRows = [];
  if (data.new_size_mb)   metaRows.push(`<span><b>${data.new_size_mb} MB</b> output size</span>`);
  if (data.saved_percent) metaRows.push(`<span><b>${data.saved_percent}%</b> saved</span>`);
  if (data.slides)        metaRows.push(`<span><b>${data.slides}</b> slides</span>`);
  if (data.duration_s)    metaRows.push(`<span><b>${data.duration_s}s</b> total</span>`);
  box.className = 'rbox ok';
  box.innerHTML = `
    <div class="rb-h">✓ ${opName} complete!</div>
    <div class="rb-f">${data.output}</div>
    ${metaRows.length ? `<div class="rb-meta">${metaRows.join('')}</div>` : ''}
    <a class="rb-dl" href="${data.download_url}" download>⬇ Download File</a>`;
  addExport(opName.toLowerCase(), data.output, data.download_url);
}

// ── Exports ─────────────────────────────────────
function addExport(op, filename, url) {
  S.exports.unshift({ op, filename, url, time: new Date() });
  renderExports();
}
function renderExports() {
  const el = document.getElementById('exp-list');
  if (!el) return;
  if (!S.exports.length) {
    el.innerHTML = '<div class="empty-state"><div class="es-ic">⬇</div><p>No exports yet</p></div>';
    return;
  }
  el.innerHTML = S.exports.map(e => `
    <div class="expc">
      <div class="expc-ico">${OP_ICONS[e.op] || '📄'}</div>
      <div class="expc-info">
        <div class="expc-op">${e.op}</div>
        <div class="expc-file">${e.filename}</div>
        <div class="expc-time">${e.time.toLocaleTimeString()}</div>
      </div>
      <a class="expc-dl" href="${e.url}" download>⬇ Download</a>
    </div>`).join('');
}
function clearExports() { S.exports = []; renderExports(); toast('Export history cleared', 'info'); }

// ══════════════════════════════════════════
//  TOOL RUNNERS
// ══════════════════════════════════════════

async function runTrim() {
  const fid   = document.getElementById('trim-file').value;
  const start = parseFloat(document.getElementById('trim-s').value) || 0;
  const end   = parseFloat(document.getElementById('trim-e').value) || 10;
  if (!fid)      { toast('Select a video file first', 'err'); return; }
  if (end <= start) { toast('End time must be greater than start', 'err'); return; }
  showOv('Trimming Video…', `Cutting ${start}s → ${end}s`);
  try {
    const d = await api('/api/trim', { file_id:fid, start, end });
    showResult('r-trim', d, 'Trim');
    if (d.success) toast('Trim complete!', 'ok'); else toast('Trim failed', 'err');
  } catch (e) { showResult('r-trim', null, 'Trim'); }
  finally { hideOv(); }
}

async function runCompress() {
  const fid = document.getElementById('compress-file').value;
  const q   = document.querySelector('input[name="cq"]:checked')?.value || 'medium';
  if (!fid) { toast('Select a video file first', 'err'); return; }
  showOv('Compressing…', 'Quality: ' + q);
  try {
    const d = await api('/api/compress', { file_id:fid, quality:q });
    showResult('r-compress', d, 'Compress');
    if (d.success) toast(`Saved ${d.saved_percent || '?'}%!`, 'ok'); else toast('Compress failed', 'err');
  } catch { showResult('r-compress', null, 'Compress'); }
  finally { hideOv(); }
}

async function runConvert() {
  const fid = document.getElementById('convert-file').value;
  const fmt = document.getElementById('convert-fmt').value;
  const res = document.getElementById('convert-res').value || null;
  if (!fid) { toast('Select a file first', 'err'); return; }
  showOv('Converting…', 'To ' + fmt.toUpperCase());
  try {
    const d = await api('/api/convert', { file_id:fid, format:fmt, resolution:res });
    showResult('r-convert', d, 'Convert');
    if (d.success) toast('Converted to ' + fmt.toUpperCase() + '!', 'ok'); else toast('Convert failed', 'err');
  } catch { showResult('r-convert', null, 'Convert'); }
  finally { hideOv(); }
}

async function runMerge() {
  const sel = [...document.getElementById('merge-files').selectedOptions].map(o => o.value);
  if (sel.length < 2) { toast('Select at least 2 videos', 'err'); return; }
  showOv('Merging ' + sel.length + ' videos…', 'This may take a moment');
  try {
    const d = await api('/api/merge', { file_ids:sel });
    showResult('r-merge', d, 'Merge');
    if (d.success) toast(sel.length + ' videos merged!', 'ok'); else toast('Merge failed', 'err');
  } catch { showResult('r-merge', null, 'Merge'); }
  finally { hideOv(); }
}

async function runAudio() {
  const fid = document.getElementById('audio-file').value;
  const fmt = document.querySelector('input[name="aq"]:checked')?.value || 'mp3';
  if (!fid) { toast('Select a video file first', 'err'); return; }
  showOv('Extracting Audio…', 'Format: ' + fmt.toUpperCase());
  try {
    const d = await api('/api/extract-audio', { file_id:fid, format:fmt });
    showResult('r-audio', d, 'Audio');
    if (d.success) toast('Audio extracted as ' + fmt.toUpperCase() + '!', 'ok'); else toast('Audio extract failed', 'err');
  } catch { showResult('r-audio', null, 'Audio'); }
  finally { hideOv(); }
}

async function runWatermark() {
  const vid = document.getElementById('wm-vid').value;
  const wm  = document.getElementById('wm-img').value;
  const pos = document.getElementById('wm-pos').value;
  const op  = parseFloat(document.getElementById('wm-op').value) / 100;
  if (!vid || !wm) { toast('Select both video and watermark image', 'err'); return; }
  showOv('Adding Watermark…');
  try {
    const d = await api('/api/add-watermark', { video_id:vid, watermark_id:wm, position:pos, opacity:op });
    showResult('r-watermark', d, 'Watermark');
    if (d.success) toast('Watermark applied!', 'ok'); else toast('Watermark failed', 'err');
  } catch { showResult('r-watermark', null, 'Watermark'); }
  finally { hideOv(); }
}

async function runText() {
  const fid  = document.getElementById('text-file').value;
  const txt  = document.getElementById('text-txt').value.trim();
  const sz   = parseInt(document.getElementById('text-sz').value) || 48;
  const col  = document.getElementById('text-col').value;
  const pos  = document.getElementById('text-pos').value;
  const t0   = parseFloat(document.getElementById('text-t0').value) || 0;
  const t1   = parseFloat(document.getElementById('text-t1').value) || 5;
  if (!fid)  { toast('Select a video file first', 'err'); return; }
  if (!txt)  { toast('Enter text content', 'err'); return; }
  if (t1 <= t0) { toast('End time must be > start time', 'err'); return; }
  showOv('Adding Text Overlay…');
  try {
    const d = await api('/api/add-text', { file_id:fid, text:txt, font_size:sz, color:col, position:pos, start_time:t0, end_time:t1 });
    showResult('r-text', d, 'Text');
    if (d.success) toast('Text overlay applied!', 'ok'); else toast('Text failed', 'err');
  } catch { showResult('r-text', null, 'Text'); }
  finally { hideOv(); }
}

async function runThumb() {
  const fid = document.getElementById('thumb-file').value;
  const ts  = parseFloat(document.getElementById('thumb-ts').value) || 1;
  if (!fid) { toast('Select a video file first', 'err'); return; }
  showOv('Extracting Frame…', 'At ' + ts + ' seconds');
  try {
    const d = await api('/api/thumbnail', { file_id:fid, timestamp:ts });
    showResult('r-thumbnail', d, 'Thumbnail');
    if (d.success) toast('Thumbnail extracted!', 'ok'); else toast('Thumbnail failed', 'err');
  } catch { showResult('r-thumbnail', null, 'Thumbnail'); }
  finally { hideOv(); }
}

async function runSpeed() {
  const fid   = document.getElementById('speed-file').value;
  const speed = parseFloat(document.getElementById('speed-rng').value) || 1;
  if (!fid)    { toast('Select a video file first', 'err'); return; }
  if (speed === 1) { toast('Change speed first (not 1×)', 'err'); return; }
  showOv('Changing Speed…', speed + '× applied via FFmpeg');
  try {
    const d = await api('/api/speed', { file_id:fid, speed });
    showResult('r-speed', d, 'Speed');
    if (d.success) toast('Speed set to ' + speed + '×!', 'ok'); else toast('Speed failed', 'err');
  } catch { showResult('r-speed', null, 'Speed'); }
  finally { hideOv(); }
}

async function runRotate() {
  const fid = document.getElementById('rotate-file').value;
  const op  = document.querySelector('.rotb.active')?.dataset.val || 'rotate_90';
  if (!fid) { toast('Select a video file first', 'err'); return; }
  showOv('Applying Transform…', op.replace(/_/g, ' '));
  try {
    const d = await api('/api/rotate', { file_id:fid, operation:op });
    showResult('r-rotate', d, 'Rotate');
    if (d.success) toast('Transform applied!', 'ok'); else toast('Rotate failed', 'err');
  } catch { showResult('r-rotate', null, 'Rotate'); }
  finally { hideOv(); }
}

// ── SLIDESHOW ───────────────────────────────────
async function runSlideshow() {
  const ms  = document.getElementById('ss-imgs');
  const ids = ms ? [...ms.selectedOptions].map(o => o.value) : [];
  if (!ids.length) { toast('Select at least 1 photo first', 'err'); return; }

  const aud = document.getElementById('ss-aud').value || '';
  const dur = parseInt(document.getElementById('ss-dur').value) || 3;
  const res = document.getElementById('ss-res').value || '1280x720';

  showOv('Creating Slideshow…', `${ids.length} photos · ${dur}s each · ${res}`);
  try {
    const d = await api('/api/slideshow', {
      image_ids: ids,
      audio_id: aud,
      duration_per_image: dur,
      resolution: res
    });
    showResult('r-slideshow', d, 'Slideshow');
    if (d.success) {
      toast(`Slideshow ready! ${ids.length} slides · ${d.duration_s}s`, 'ok');
      switchPanel('exports');
      setTimeout(() => switchPanel('slideshow'), 100);
    } else {
      toast('Slideshow failed — check Exports or try again', 'err');
    }
  } catch (e) {
    showResult('r-slideshow', { error: e.message }, 'Slideshow');
  } finally {
    hideOv();
  }
}

// ── BATCH ───────────────────────────────────────
function addBatch() {
  const fid = document.getElementById('bch-file').value;
  const op  = document.getElementById('bch-op').value;
  if (!fid) { toast('Select a file for the batch job', 'err'); return; }
  const fname = S.media.find(m => m.file_id === fid)?.filename || fid;
  S.batch.push({ fid, fname, op, status:'pending', result:null });
  renderBatch();
  document.getElementById('btn-batch').disabled = false;
  toast('Job added: ' + op, 'info');
}

function removeBatch(i) {
  S.batch.splice(i, 1);
  renderBatch();
  if (!S.batch.length) document.getElementById('btn-batch').disabled = true;
}

function clearBatch() {
  S.batch = [];
  renderBatch();
  document.getElementById('btn-batch').disabled = true;
}

function renderBatch() {
  const list = document.getElementById('bq-list');
  const cnt  = document.getElementById('bq-cnt');
  if (cnt) cnt.textContent = S.batch.length;
  if (!list) return;
  if (!S.batch.length) {
    list.innerHTML = '<div class="empty-state"><div class="es-ic">⚡</div><p>Add jobs above</p></div>';
    return;
  }
  list.innerHTML = S.batch.map((j, i) => `
    <div class="bqj">
      <div class="bqj-n">${i+1}</div>
      <div class="bqj-info">
        <div class="bqj-op">${j.op}</div>
        <div class="bqj-f">${j.fname}</div>
      </div>
      <span class="bqs ${j.status}">${j.status}</span>
      ${j.status === 'pending' ? `<button class="bqj-rm" onclick="removeBatch(${i})">✕</button>` : ''}
      ${j.result?.download_url ? `<a class="rb-dl" href="${j.result.download_url}" download style="padding:4px 9px;font-size:.72rem">⬇</a>` : ''}
    </div>`).join('');
}

async function runBatch() {
  const pending = S.batch.filter(j => j.status === 'pending');
  if (!pending.length) { toast('No pending jobs', 'info'); return; }
  document.getElementById('btn-batch').disabled = true;

  for (let i = 0; i < S.batch.length; i++) {
    const j = S.batch[i];
    if (j.status !== 'pending') continue;
    j.status = 'running'; renderBatch();
    showOv(`Batch: ${j.op}`, `Job ${i+1} of ${S.batch.length}`);

    try {
      const [op, param] = j.op.split(':');
      let endpoint = '', payload = { file_id: j.fid };
      if      (op === 'compress')  { endpoint = '/api/compress';      payload.quality = param; }
      else if (op === 'convert')   { endpoint = '/api/convert';       payload.format  = param; }
      else if (op === 'audio')     { endpoint = '/api/extract-audio'; payload.format  = param; }
      else if (op === 'thumbnail') { endpoint = '/api/thumbnail';     payload.timestamp = 1; }

      const d = await api(endpoint, payload);
      j.result = d;
      j.status = d.success ? 'done' : 'fail';
      if (d.success) addExport('batch', d.output, d.download_url);
    } catch (e) {
      j.status = 'fail'; j.result = { error: e.message };
    }
    renderBatch();
  }

  hideOv();
  const done = S.batch.filter(j => j.status === 'done').length;
  const fail = S.batch.filter(j => j.status === 'fail').length;
  toast(`Batch done: ${done} ok, ${fail} failed`, done > 0 && fail === 0 ? 'ok' : 'info');
}
